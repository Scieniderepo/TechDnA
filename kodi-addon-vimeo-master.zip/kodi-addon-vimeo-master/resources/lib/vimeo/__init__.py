#! /usr/bin/env python
# encoding: utf-8

version = (0, 3, 10)

from .client import VimeoClient  # noqa: E402
from . import exceptions  # noqa: E402
