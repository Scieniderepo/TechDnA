

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.CountryBox'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
icon2   = "https://ia601404.us.archive.org/23/items/1_20200805_20200805_0150/1.jpg"
icon3   = "https://ia601406.us.archive.org/19/items/1_20200805_202008/2.jpg"
icon4   = "https://ia601406.us.archive.org/19/items/1_20200805_202008/3.jpg"
icon5   = "https://yt3.ggpht.com/a/AATXAJxQ-v2C8fOL0WnHleDJgvUkyfMxeLDDauLqVbKF=s100-c-k-c0xffffffff-no-rj-mo"
icon6   = "https://yt3.ggpht.com/-OKTcW1zbTcU/AAAAAAAAAAI/AAAAAAAAAAA/C1bfoXTyd2U/s500-mo-c-c0xffffffff-rj-k-no/photo.jpg"
icon7   = "https://yt3.ggpht.com/-5iUU1rnzBWg/AAAAAAAAAAI/AAAAAAAAAAA/76Ii3uSkuIg/s500-mo-c-c0xffffffff-rj-k-no/photo.jpg"
base    = 'plugin://plugin.video.youtube/'


def run():
    plugintools.log("CountryBox.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):

    
                
    



		plugintools.log("rsa ===> " + repr(params))
                #plugintools.add_item(title = "RSA Music"         , url = base + "channel/UC4J156Jz2u_CjEyUSmQgh6g/",       thumbnail = icon, folder = True)
                plugintools.add_item(title = "Country Love Songs"         , url = base + "playlist/OLAK5uy_mSWOm03ORYddkejJisHoN-ggvpEj9AA78/",       thumbnail = icon2, folder = True)
                plugintools.add_item(title = "Country Collection"         , url = base + "playlist/PLevlFJ4sr2ynLDf6AGxC6QtnLwHGeCQX7/",       thumbnail = icon3, folder = True)
                plugintools.add_item(title = "Country Music Collection"   , url = base + "channel/UCgV30q6xaHwnlDQiL6H_UgQ/",       thumbnail = icon4, folder = True)
                plugintools.add_item(title = "Classic Country"            , url = base + "channel/UCf_QlbcG6TRSqAStEdjJnkA/",       thumbnail = icon5, folder = True)
                plugintools.add_item(title = "Country Experience"         , url = base + "channel/UC93EEyk9ZHkB4b4RX-mn9WA/",       thumbnail = icon6, folder = True)
                plugintools.add_item(title = "Music Forever"              , url = base + "channel/UCGb4NnjOVmTwTSzjTBVblVA/",       thumbnail = icon7, folder = True)
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')

run()
