# -*- coding: utf-8 -*-

'''
    Fashion TV Player Addon
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

main_link = 'https://www.fashiontv.com/'
fashion_tv_yt_channel = 'UCqzju-_WMKsgNx8R3QwupQQ'
ftv_yt_channel = 'UClnblsrZrugJfFs4ANPgNcA'
ftv_hot_yt_channel = 'UCDN6BTcfgHDuBQgCgXkU-cA'
ftv_parties_yt_channel = 'UCLiyW3PZFDSxIw6EES8MneQ'
ftv_asia_yt_channel = 'UCC2Iic6b-nhY7CSRUm_nyng'
ftv_news_channel = 'UCi12i9eiWFh67T-uCP1y7Gw'
scramble = (
    'eJwVy8EKgjAAANBfiZ1TmnM6u4lFhUGEqXgKnctk04lbK43+Pby/9wWK0ZFpsF2BNFAHAt+5yz7mxptOpfE1d3EB1itQDu2ds2lh4Wkuky'
    'lSIrqQc4aS+RhyQp+WyGK8Hwu+q7nXTWRZbb0E38MOdDBEAUIWbA19aFcbLDjkTuebTcXECD0iKuNJ3y6HQdmNlI1gL8VGKnvNem1T2YHf'
    'H4uyN8w='
)
