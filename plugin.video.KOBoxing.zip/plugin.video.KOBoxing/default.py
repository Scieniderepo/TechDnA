# -*- coding: utf-8 -*-
#------------------------------------------------------------
# KO Boxing
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.KOBoxing'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_PLAYLIST_ID1 = "PL0i1N-wlFfiDEdYCjp6nvHR-sEpJGBGXZ"
YOUTUBE_PLAYLIST_ID2 = "PLhex79nDxQrVNdUeo_7qV8O8MUztCE8VM"
YOUTUBE_PLAYLIST_ID3 = "PL4892D2D4D615ECE5"
YOUTUBE_PLAYLIST_ID4 = "PL317FB17EC1AEDA3E"
YOUTUBE_PLAYLIST_ID5 = "PL17555154C13A6B21"
YOUTUBE_PLAYLIST_ID6 = "PL61E39C7037FF8710"
YOUTUBE_PLAYLIST_ID7 = "UCSIZMMUh3_8L6oy4Jl7w44w"
YOUTUBE_PLAYLIST_ID8 = "UCdl_gZZR6BtKi45eHFGAduw"

# Entry point
def run():
    plugintools.log("KOBoxing.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("KOBoxing.main_list "+repr(params))
        
    plugintools.add_item( 
        #action="", 
        title="Classic Boxing Matches",
        url="plugin://plugin.video.youtube/channel/UCrvszWERpkC8g1dck5yLQTw/playlist/"+YOUTUBE_PLAYLIST_ID1+"/",
        thumbnail=icon,
        folder=True )
		  
    plugintools.add_item( 
        #action="", 
        title="Classic Boxing Matches 2",
        url="plugin://plugin.video.youtube/channel/UCxiINk_8yDbFUlUTxFvcEOw/playlist/"+YOUTUBE_PLAYLIST_ID2+"/",
        thumbnail=icon,
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Full Boxing Matches",
        url="plugin://plugin.video.youtube/channel/UCvGoV5k57qhzALZTnn9sohw/playlist/"+YOUTUBE_PLAYLIST_ID4+"/",
        thumbnail=icon,
        folder=True )
					  			 
    plugintools.add_item( 
        #action="", 
        title="Full Boxing Matches 2",
        url="plugin://plugin.video.youtube/channel/UCRujjyxUSwXwY1y--lAYrJA/playlist/"+YOUTUBE_PLAYLIST_ID6+"/",
        thumbnail=icon,
        folder=True )
							 
    plugintools.add_item( 
        #action="", 
        title="HBO Boxing Greatest Hits",
        url="plugin://plugin.video.youtube/channel/UCWPQB43yGKEum3eW0P9N_nQ/playlist/"+YOUTUBE_PLAYLIST_ID5+"/",
        thumbnail=icon,
        folder=True )
				  			 
    plugintools.add_item( 
        #action="", 
        title="HBO Boxing Highlights",
        url="plugin://plugin.video.youtube/channel/UCWPQB43yGKEum3eW0P9N_nQ/playlist/"+YOUTUBE_PLAYLIST_ID3+"/",
        thumbnail=icon,
        folder=True )
		  			 
    plugintools.add_item( 
        #action="", 
        title="IFL TV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_PLAYLIST_ID8+"/",
        thumbnail=icon,
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="UK Fights",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_PLAYLIST_ID7+"/",
        thumbnail=icon,
        folder=True )
		
		

run()