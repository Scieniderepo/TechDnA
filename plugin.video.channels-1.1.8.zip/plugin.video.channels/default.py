# -*- coding: utf-8 -*-

# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)

import urllib, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
#import urllib2

try:
    # Python 3
    from urllib.request import urlopen, Request
except ImportError:
    # Python 2
    from urllib2 import urlopen, Request

try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

from koding import route, Addon_Setting, Add_Dir, Find_In_Text, Open_URL, OK_Dialog
from koding import Open_Settings, Play_Video, Run, Text_File

from resources.lib.modules.moviechannels import *
from resources.lib.modules.common import *

params = get_params()
mode = None

addon_id     = xbmcaddon.Addon().getAddonInfo('id') 
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
plugin_handle = int(sys.argv[1])
dialog = xbmcgui.Dialog()
mysettings = xbmcaddon.Addon(id = 'plugin.video.channels')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
mediapath = 'http://j1wizard.net/media/'
#path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

@route(mode='main')
def Main():

	add_link_info('[B][COLORorange]== Channels ==[/COLOR][/B]', mediapath+'channels.png', fanart)
	addDirMain('[COLOR white][B]Live Channels[/B][/COLOR]',BASE,120,mediapath+'channels-live.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Horror Channels[/B][/COLOR]',BASE,110,mediapath+'channels-horror.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sci-fi Channels[/B][/COLOR]',BASE,111,mediapath+'channels-scifi.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Family Channels[/B][/COLOR]',BASE,118,mediapath+'channels-family.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Anime Channels[/B][/COLOR]',BASE,114,mediapath+'channels-anime.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Sports Channels[/B][/COLOR]',BASE,117,mediapath+'channels-sports.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Wrestling Channels[/B][/COLOR]',BASE,122,mediapath+'channels-wrestling.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Animation Channels[/B][/COLOR]',BASE,119,mediapath+'channels-animation.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Documentary Channels[/B][/COLOR]',BASE,115,mediapath+'channels-docs.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Classic Movie Channels[/B][/COLOR]',BASE,116,mediapath+'channels-classic.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Mixed Movie Channels[/B][/COLOR]',BASE,113,mediapath+'channels-mixed.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]Music Channels[/B][/COLOR]',BASE,121,mediapath+'channels-music.png',mediapath+'fanart.jpg')
	addDirMain('[COLOR white][B]By Year Playlists[/B][/COLOR]',BASE,112,mediapath+'channels-years.png',mediapath+'fanart.jpg')
	add_link_info('[B][COLORorange] [/COLOR][/B]', mediapath+'channels.png', fanart)

#==========================================================================================================

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


def get_setting(setting):
    return addon.getSetting(setting)

def set_setting(setting, string):
    return addon.setSetting(setting, string)

def get_string(string_id):
    return addon.getLocalizedString(string_id)

def play_videoID(id):
		
    errorMsg="%s" % (id)
    xbmcgui.Dialog().ok("id", errorMsg)

    #xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=<VIDEO-ID>)')
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=%s)') % (id)
    return

#==========================================================================================================
		
params=get_params()
url=None
name=None
iconimage=None
mode=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode = urllib.unquote_plus(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
#print "mode: "+str(mode)
#print "URL: "+str(url)
#print "Name: "+str(name)

if mode == 110:
	HorrorChannel()
		
elif mode == 111:
	ScifiChannel()		
		
elif mode == 112:
	Playlists()

elif mode == 113:
	MixedChannel()
	
elif mode == 114:
	AnimeChannel()

elif mode == 115:
	DocumentaryChannel()

elif mode == 116:
	ClassicChannel()

elif mode == 117:
	SportsChannel()
	
elif mode == 118:
	FamilyChannel()

elif mode == 119:
	AnimationChannel()

elif mode == 120:
	LiveChannel()

elif mode == 121:
	MusicChannel()

elif mode == 122:
	WrestlingChannel()

elif mode is None and mode is None:
	Main()
		
xbmcplugin.endOfDirectory(plugin_handle)

#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()
#----------------------------------------------------------------
# A basic OK Dialog
@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

#if __name__ == "__main__":
#    Run(default='main')
#    xbmcplugin.endOfDirectory(int(sys.argv[1]))