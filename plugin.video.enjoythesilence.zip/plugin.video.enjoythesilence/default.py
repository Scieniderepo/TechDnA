# -*- coding: utf-8 -*-
#------------------------------------------------------------
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.enjoythesilence'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID1 = "UCjoFckSzE1jUM_kmtVHNlKg"
YOUTUBE_CHANNEL_ID2 = "UCg72Hd6UZAgPBAUZplnmPMQ"
YOUTUBE_CHANNEL_ID3 = "cattrumpetmusic"
YOUTUBE_CHANNEL_ID4 = "UCrr6J2SOYZLJ2LF8RNnMnzg"
YOUTUBE_CHANNEL_ID5 = "UCTTqBgYdkmFogITlPDM0M4A"
YOUTUBE_CHANNEL_ID6 = "dhuting"
YOUTUBE_CHANNEL_ID7 = "UC95bEkaIgwhxSjSsdMFXYGg"
YOUTUBE_CHANNEL_ID8 = "UCeql7fiedRtT0tU92Kby-Ag"




# Entry point
def run():
    plugintools.log("enjoythesilence.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("enjoythesilence.main_list "+repr(params))

	
    
    plugintools.add_item( 
        #action="", 
        title="Fogatas",
        url="plugin://plugin.video.youtube/playlist/PLGH_5Dpd62t1kiML0DLurpoSS7U7ZuQ6h/",
        thumbnail="https://1.bp.blogspot.com/-JTrYG_sITuo/X9zLIRrPXBI/AAAAAAABoqQ/4m79SQpi-8AC3ucfUqPEqJ6Zj6cqtmRCgCLcBGAsYHQ/s16000/janko-ferlic-z8Cr7UW4nfs-unsplash.jpg",
        fanart="https://1.bp.blogspot.com/-8IHVWjKpoqw/X9zKlVVyF5I/AAAAAAABoqI/kNRpna4Crnsbrb3l_0qBw655w7X6siFkgCLcBGAsYHQ/s16000/almos-bechtold-GFgWx3o8bTI-unsplash.jpg",
        folder=True )
        
   
    plugintools.add_item( 
        #action="", 
        title="Aerial Dron",
        url="plugin://plugin.video.youtube/playlist/PLbWPytS1GWJJk4Exgs6DNR0jhhUxZBjCb/",
        thumbnail="https://1.bp.blogspot.com/-YITj-kLSXbg/X94yuScSLRI/AAAAAAABots/gVLAygwi96IQSQ_kZZJkf2yW8tlpiP8EwCLcBGAsYHQ/s16000/NEGRO%2B%25281%2529.jpg",
        fanart="https://1.bp.blogspot.com/-IHXnpknHVhE/X94zOj8MT8I/AAAAAAABot0/cB5pfRBnLXkQwlCdXmJ-xGyIK8AY4oBFwCLcBGAsYHQ/s16000/Wallpaper-Mountain-Loop-Highway%252C-Aerial-view%252C-Drone-photo-.jpg",
        folder=True )
        
        
    plugintools.add_item( 
        #action="", 
        title="Winter",
        url="plugin://plugin.video.youtube/playlist/PLGH_5Dpd62t2A1yBZNB_eRjEvbnlr_sHR/",
        thumbnail="https://1.bp.blogspot.com/-kE7rMl-ffyA/X95Zaxr9ZeI/AAAAAAABouY/qQ8WN1wEHEowRYEWBJ3Z8tfXx2wDePkagCLcBGAsYHQ/s16000/NEGRO%2B%25282%2529.jpg",
        fanart="https://1.bp.blogspot.com/-ufJ6XxB5Des/X95Z61b1pVI/AAAAAAABoug/C56OyanRdtwpHzYP9y4kjk7ZjCWJb7UYACLcBGAsYHQ/s16000/todd-diemer-67t2GJcD5PI-unsplash.jpg",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="Vida Salvaje Supervivencia",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="https://1.bp.blogspot.com/-ieviqnwlPxo/X9-cNZy-rAI/AAAAAAABox8/4CRP1d7kP6gsqQF1Bur0RjJad_P0Tnh1ACLcBGAsYHQ/s16000/NEGRO%2B%25288%2529.jpg",
		fanart="https://1.bp.blogspot.com/-r7wexX7MnOI/X9-cYXk_9JI/AAAAAAABoyA/X4BrLK_82kQaaT0Y_7FQHLi4xqkrN7uXACLcBGAsYHQ/s16000/amos-g-IrGYJPF0JS0-unsplash.jpg",
        folder=True )   
   
   
    plugintools.add_item( 
        #action="", 
        title="Nature Soundscapes",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="https://1.bp.blogspot.com/-kxOzmeNmfJw/X934yzVLHyI/AAAAAAABosE/cKY2FClSzN4KJganuQ16VylIGlCVS1MmgCLcBGAsYHQ/s474/NEGRO.jpg",
		fanart="https://1.bp.blogspot.com/-BgJ7LiKlt8E/X94dauVZucI/AAAAAAABos0/SAXopYLb3JkNBlgP9fUv4u12hQDUuJ3swCLcBGAsYHQ/s2048/michael-tomlinson-JceYr1gda6E-unsplash.jpg",
        folder=True )     
        
    plugintools.add_item( 
        #action="", 
        title="Dovado",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail="https://1.bp.blogspot.com/-R0sLfMn5uoA/X99tytrp3aI/AAAAAAABovs/uPimcisprn8RRPzWh1jNzLHraAJuTMT6ACLcBGAsYHQ/s474/NEGRO%2B%25284%2529.jpg",
		fanart="https://1.bp.blogspot.com/-I54zIO_FOyg/X991H8tGEAI/AAAAAAABov8/KXjFn3Sl4zMrJiMhwjKSen55ngvvYjt_wCLcBGAsYHQ/s16000/ostap-senyuk-EstnBZqJkJ4-unsplash.jpg",
        folder=True )  
        
       
    plugintools.add_item( 
        #action="", 
        title="4K Relaxation Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="https://1.bp.blogspot.com/-50vLR9wKnwc/X937gwkWLOI/AAAAAAABosY/q2rBGiHjPDwIaHQumJAEEs1YTO7DuOlywCLcBGAsYHQ/s16000/NEGRO2.jpg",
		fanart="https://1.bp.blogspot.com/-SjUQEsFRwIQ/X938iu3sQsI/AAAAAAABoso/DolZ931h2B4JslXqn7CDlwFnN0nfSom7wCLcBGAsYHQ/s16000/7777.jpg",
        folder=True )     
  
    plugintools.add_item( 
        #action="", 
        title="DroneScapes",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail="https://1.bp.blogspot.com/-kV0pyo0AxCk/X9-HVvIgbEI/AAAAAAABows/-_I4x9S4qdgNsCk_hJLqN7WC5WGmTBxqQCLcBGAsYHQ/s16000/NEGRO%2B%25285%2529.jpg",
		fanart="https://1.bp.blogspot.com/-pKLh8pgbWF4/X9-GjQY9EJI/AAAAAAABowg/vJ_yEev5u74pVwrWWABBeCqsAt_rROjgQCLcBGAsYHQ/s16000/090151mzdu0fyyouo08w0w.jpeg",
        folder=True )   
        
           
           
    plugintools.add_item( 
        #action="", 
        title="Cat Trumpet",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail="https://1.bp.blogspot.com/-wPM-E-LMK5w/X95ffmdjb2I/AAAAAAABous/tqzunxmmxQIjVozybAXF9OlmgcqfNRymwCLcBGAsYHQ/s474/NEGRO%2B%25283%2529.jpg",
		fanart="https://1.bp.blogspot.com/-_U5xL3Tt_No/X95fxfuBjFI/AAAAAAABou0/HiN7M-DZVIAHku8T-SxeVkqZqKO_Sx_pgCLcBGAsYHQ/s2048/jasper-boer-LJD6U920zVo-unsplash.jpg",
        folder=True )     
        
                   
    plugintools.add_item( 
        #action="", 
        title="Nature Relaxation Films",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail="https://1.bp.blogspot.com/-hBe8tcCgsMw/X9-VtjvpWuI/AAAAAAABoxQ/5QN_gzRcdecELmHfHbynGgVu7wWzUow9gCLcBGAsYHQ/s16000/NEGRO%2B%25286%2529.jpg",
		fanart="https://1.bp.blogspot.com/-kS8BzDinNlM/X9-UV8Vic7I/AAAAAAABoxE/DyDMCWfoo7cHZzd6Y7aIZmSGvNGrwj0-wCLcBGAsYHQ/s16000/aerial-collection-collection-banner.jpg",
        folder=True )  
    
    
    plugintools.add_item( 
        #action="", 
        title="Scenic Relaxation",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="https://1.bp.blogspot.com/-DaXqM38pxdo/X9-XeD8aBcI/AAAAAAABoxk/aMqY4SXgDewemtfjn_2NiX1jjSJOlX3oACLcBGAsYHQ/w640-h640/NEGRO%2B%25287%2529.jpg",
		fanart="https://1.bp.blogspot.com/-bOYzBvI9EHI/X9-Wt7y_MsI/AAAAAAABoxY/1UF94UiOv9Ybv1zs7rpSUFmUUNgUM_3WwCLcBGAsYHQ/s16000/glacierbg.jpg",
        folder=True )  
            
            

       
   
        
        
run()