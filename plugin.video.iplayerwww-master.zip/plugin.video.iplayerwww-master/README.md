# plugin.video.iplayerwww
BBC iPlayer for Kodi
Support: https://forum.kodi.tv/showthread.php?tid=353349
Author: CaptainT
