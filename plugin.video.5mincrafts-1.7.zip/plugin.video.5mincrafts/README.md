# plugin.video.fitnessblender

![logo](https://github.com/dangelus1138/plugin.video.fitnessblenderv2/raw/master/resources/images/banner.png)

Kodi add-on for the Youtube channel of Fitness Blender https://www.fitnessblender.com/

Fitness Blender provides free full length workout videos, workout routines, healthy recipes and more.

