# -*- coding: utf-8 -*-
from Lib.Plugin import main

main() # See bottom of Plugin.py.