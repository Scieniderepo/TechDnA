# Max-Movies-Kodi-Addon
Max Movies is a kodi addon that scrapes movies, tv shows and live TV channels from https://www.mxplayer.in/

# Note: This plugin can play DRM Files too!

# Screenshots
![Screenshot (10)](https://user-images.githubusercontent.com/68910039/113399042-2e4f8f00-93bd-11eb-9cfc-925a37be73c9.png)
![Screenshot (11)](https://user-images.githubusercontent.com/68910039/113399046-30b1e900-93bd-11eb-89fc-7df1f5952c4e.png)
![Screenshot (12)](https://user-images.githubusercontent.com/68910039/113399049-31e31600-93bd-11eb-8a8e-71aba89cfdde.png)

## Donations
If you like my projects then consider making a small donation by clicking below button ^_^
<br/>
[![](https://img.shields.io/badge/Donate-Paypal-blue?style=for-the-badge&logo=paypal)](https://www.paypal.com/paypalme/henryrics)

# Copyrights © [Henry Richard J](https://github.com/henry-richard7)
#### Star the Repo in case you liked it :)
